import json
import os
import boto3
import logging
from urllib.parse import unquote_plus
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
bedrock = boto3.client('bedrock-runtime')

JOBS_TABLE = os.environ.get('JOBS_TABLE')
ANALYSIS_PREFIX = "analysis/"

def get_job_metadata(job_id):
    """Fetch job metadata from DynamoDB"""
    table = dynamodb.Table(JOBS_TABLE)
    response = table.get_item(Key={'jobId': job_id})
    return response.get('Item')

def update_job_status(job_id, status, analysis_key=None):
    """Update job status in DynamoDB"""
    table = dynamodb.Table(JOBS_TABLE)
    update_expr = "SET #s = :s, updatedAt = :t"
    expr_attr_names = {'#s': 'status'}
    expr_attr_values = {':s': status, ':t': datetime.utcnow().isoformat()}
    
    if analysis_key:
        update_expr += ", analysisKey = :k"
        expr_attr_values[':k'] = analysis_key

    table.update_item(
        Key={'jobId': job_id},
        UpdateExpression=update_expr,
        ExpressionAttributeNames=expr_attr_names,
        ExpressionAttributeValues=expr_attr_values
    )

def invoke_bedrock_analysis(transcription_text):
    """Call Bedrock (Claude 3 Sonnet) to analyze text"""
    prompt = f"""
    You are an expert content analyzer. Analyze the following podcast transcription and provide a structured JSON response.
    
    Transcription:
    {transcription_text[:100000]}  # Limit context window if necessary

    Output Format (JSON only):
    {{
        "summary": "Concise executive summary (3-4 sentences)",
        "topics": ["list", "of", "main", "topics"],
        "sentiment": "POSITIVE" | "NEUTRAL" | "NEGATIVE",
        "entities": ["list", "of", "key", "people/places/orgs"],
        "chapters": [
             {{ "timestamp": "00:00", "title": "Intro" }}
        ]
    }}
    
    Do not include any text outside the JSON block.
    """

    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 2000,
        "temperature": 0.1,
        "messages": [
            {
                "role": "user",
                "content": [{"type": "text", "text": prompt}]
            }
        ]
    })

    try:
        response = bedrock.invoke_model(
            modelId="anthropic.claude-3-sonnet-20240229-v1:0",
            body=body
        )
        
        response_body = json.loads(response.get('body').read())
        result = response_body['content'][0]['text']
        
        # Parse JSON from LLM response
        try:
            return json.loads(result)
        except json.JSONDecodeError:
            # Fallback if model returns text wrapper
            start = result.find('{')
            end = result.rfind('}') + 1
            if start != -1 and end != -1:
                return json.loads(result[start:end])
            return {"error": "Failed to parse JSON", "raw_response": result}

    except Exception as e:
        logger.error(f"Bedrock invocation failed: {e}")
        raise

def handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])
        
        # key format: transcriptions/{job_id}/transcription.json
        # Extract Job ID
        parts = key.split('/')
        if len(parts) < 3 or parts[-1] != 'transcription.json':
            logger.info("Skipping non-final transcription file")
            continue
            
        job_id = parts[1]
        logger.info(f"Processing analysis for Job ID: {job_id}")

        try:
            # 1. Read Transcription
            obj = s3_client.get_object(Bucket=bucket, Key=key)
            transcription_data = json.loads(obj['Body'].read().decode('utf-8'))
            
            # Extract full text (depending on format, might needs keys 'results' -> 'transcripts' -> 'transcript')
            # Based on Post-Processor, we saved a simple dict or string. Let's assume standard format.
            # Post-processor from previous phase saves: {"job_id":..., "text": "FULL TEXT", ...}
            full_text = transcription_data.get('text', '')
            
            if not full_text:
                logger.warning("No text found in transcription")
                return

            # 2. Invoke Bedrock
            analysis_result = invoke_bedrock_analysis(full_text)
            
            # 3. Save Analysis to S3
            analysis_key = f"{ANALYSIS_PREFIX}{job_id}.json"
            s3_client.put_object(
                Bucket=bucket,
                Key=analysis_key,
                Body=json.dumps(analysis_result, indent=2),
                ContentType='application/json'
            )
            logger.info(f"Saved analysis to {analysis_key}")

            # 4. Update Status
            update_job_status(job_id, "analyzed", analysis_key)

        except Exception as e:
            logger.error(f"Error analyzing job {job_id}: {e}")
            raise e
            
    return {"status": "success"}
